import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MoviesComponent } from './movies/movies.component';
import { MovieResolverService } from './movies/movie-resolver.service';
import { MovieComponent } from './movies/movie.component';

const routes: Routes = [
  {
    path: 'movies',
    component: MoviesComponent,
    resolve: { movieList: MovieResolverService }
  },
  { path: 'movie/:id/:slug', component: MovieComponent },
  { path: '', redirectTo: 'movies', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
