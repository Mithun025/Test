import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MovieService } from './movie.service';
import { IMovie } from './movie';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  movieID: string;
  movieDetail: IMovie;

  constructor(private _route: ActivatedRoute,
              private _movieService: MovieService) { }

  ngOnInit() {
    this.movieID = this._route.snapshot.paramMap.get('id');
    this._movieService.getMovieById(this.movieID).subscribe((res: IMovie) => {
      this.movieDetail = res;
    });
  }


}
