import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IMovie } from './movie'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  baseUrl = 'https://backend-ygzsyibiue.now.sh/api/v1/movies/';

  constructor(private _http: HttpClient) { }

  getMovies(): Observable<IMovie[]> {
    return this._http.get<IMovie[]>(this.baseUrl);
  }

  getMovieById(id:string):Observable<IMovie>{
    return this._http.get<IMovie>(this.baseUrl + '/' + id);
  }
}
