export interface IMovie {
    _id: string;
    title: string;
    slug: string;
    releaseDate: string;
    posterURL: string;
    backdropURL: string;
    plot: string
}
