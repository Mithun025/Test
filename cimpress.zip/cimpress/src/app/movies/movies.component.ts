import { Component, OnInit } from '@angular/core';
import { IMovie } from './movie';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  movieList: IMovie[] = [];

  constructor(private _route: ActivatedRoute,
    private _router: Router) { }

  ngOnInit() {
    this.movieList = this._route.snapshot.data['movieList'];
  }

  onClick(id: string, slug: string) {
    this._router.navigate(['movie', id, slug]);
  }

}
